namespace TruckFactoryLibrary
{
    public class ContainerTruckFactory : TruckFactory
    {
        public override ITruck CreateTruck()
        {
            return new ContainerTruck();
        }
    }
}