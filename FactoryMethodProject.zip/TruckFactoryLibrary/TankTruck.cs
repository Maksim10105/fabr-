using System;

namespace TruckFactoryLibrary
{
    public class TankTruck : ITruck
    {
        public void Deliver()
        {
            Console.WriteLine("Delivering liquids with a Tank Truck.");
        }
    }
}