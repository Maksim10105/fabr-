using System;

namespace TruckFactoryLibrary
{
    public class ContainerTruck : ITruck
    {
        public void Deliver()
        {
            Console.WriteLine("Delivering containers with a Container Truck.");
        }
    }
}