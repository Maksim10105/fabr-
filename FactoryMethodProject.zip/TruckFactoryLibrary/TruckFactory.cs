namespace TruckFactoryLibrary
{
    public abstract class TruckFactory
    {
        public abstract ITruck CreateTruck();
    }
}