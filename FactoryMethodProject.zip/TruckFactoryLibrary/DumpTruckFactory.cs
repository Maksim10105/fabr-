namespace TruckFactoryLibrary
{
    public class DumpTruckFactory : TruckFactory
    {
        public override ITruck CreateTruck()
        {
            return new DumpTruck();
        }
    }
}