namespace TruckFactoryLibrary
{
    public class TankTruckFactory : TruckFactory
    {
        public override ITruck CreateTruck()
        {
            return new TankTruck();
        }
    }
}