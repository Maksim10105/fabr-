using System;

namespace TruckFactoryLibrary
{
    public class DumpTruck : ITruck
    {
        public void Deliver()
        {
            Console.WriteLine("Delivering bulk materials with a Dump Truck.");
        }
    }
}