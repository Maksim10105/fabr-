namespace TruckFactoryLibrary
{
    public interface ITruck
    {
        void Deliver();
    }
}