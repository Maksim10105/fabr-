using System;
using TruckFactoryLibrary;

namespace FactoryMethodDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            TruckFactory[] factories = {
                new DumpTruckFactory(),
                new TankTruckFactory(),
                new ContainerTruckFactory()
            };

            foreach (var factory in factories)
            {
                ITruck truck = factory.CreateTruck();
                truck.Deliver();
            }
        }
    }
}